import java.util.Random;

public class Adversario {

    private String Nome;

    private float Vida;

    private float VidaAtual;

    private float Força;

    private float Resistencia;

    private int destreza;

    private int agilidade;

    private float PM;

    private float Mana;

    private float ManaAtual;

    private boolean Defesa = false;

    private boolean PularTurno = false;

    private boolean SemMagia = false;
    
    private boolean SemPorçãoV = false;

    private boolean SemPorçãoM = false;

    private boolean MenosDano = false;

    private int Açao;

    Arma InimigoArma;

    Armadura InimigoArmadura;

    Random Ação = new Random();

    Pocao porções = new Pocao(3, 3);

    Random drop = new Random();

    public void setPoderPorções(float Poder) {
        porções.poder(Poder);
    }

    Adversario(String Nome, float Vida, float Força, float Resistencia, int agilidade, int destreza, float PM,
            float Mana) {
        this.Nome = Nome;
        this.Vida = Vida;
        this.VidaAtual = this.Vida;
        this.Força = Força;
        this.Resistencia = Resistencia;
        this.agilidade = agilidade;
        this.destreza = destreza;
        this.PM = PM;
        this.Mana = Mana;
        this.ManaAtual = this.Mana;
    }

    public void criarArma(String nome, int tipo, int constante) {
        InimigoArma = new Arma(nome, tipo, constante, this.destreza);
    }

    public void criarArmadura(String nome, int constante) {
        InimigoArmadura = new Armadura(nome, this.Resistencia, constante);
    }

    public boolean getisPularTurno() {
        return PularTurno;
    }
    public void setisPularTurno(boolean Turno){
    this.PularTurno = Turno;
    }

    public String getNome() {
        return Nome;
    }

    public float getVida() {
        return Vida;
    }
    
    public int getAçao() {
        return Açao;
    }

    public float getVidaAtual() {
        return VidaAtual;
    }

    public float getMana() {
        return Mana;
    }

    public float getManaAtual() {
        return ManaAtual;
    }

    public int getAgilidade() {
        return agilidade;
    }
    
    public boolean isSemMagia() {
        return SemMagia;
    }

    public boolean isSemPorçãoV() {
        return SemPorçãoV;
    }

    public boolean isSemPorçãoM() {
        return SemPorçãoM;
    }

    public boolean isMenosDano() {
        return MenosDano;
    }

    public void setMenosDano(boolean menosDano) {
        MenosDano = menosDano;
    }

    public void TomarDano(float Dano) {
        if (Defesa == true) {
            float aux = Dano - InimigoArmadura.Defender();
            aux = Math.max(aux, 0);
            this.VidaAtual -= aux;
        } else {
            float danoFinal = Dano - InimigoArmadura.getConstante();
            danoFinal = Math.max(danoFinal, 0);
            this.VidaAtual -= danoFinal;
        } 
    }
    

    public float DarDano() {
        float Dano = InimigoArma.CalularDano(this.Força);
        this.PularTurno = false;
        return Dano;
    }

    public void UsarPoção(int T) {
        float aux;
        if (T == 1) {
            aux = porções.RecuperarVida(this.Vida, this.VidaAtual);
            if (aux > 0) {
                this.VidaAtual = aux;
                this.PularTurno = false;
            } else if(aux == 0){
                this.SemPorçãoV = true;
                this.PularTurno = true;
            }
            else{
                this.PularTurno = true;
            }
        } else if (T == 2) {
            aux = porções.RecuperarMana(this.Mana, this.ManaAtual);
            if (aux > 0) {
                this.ManaAtual = aux;
                this.PularTurno = false;
            } else if(aux == 0){
                this.SemPorçãoM = true;
                this.PularTurno = true;
            }
            else{
                this.PularTurno = true;
            }
        }
    }

    public float Magia() {
       if(this.ManaAtual >= 50){ 
        this.ManaAtual -= 50;
        if(this.MenosDano == false){
        PM =(float) (this.PM * 1.5);
        PM = InimigoArma.Magia(PM);
        this.PularTurno = false;
        this.SemMagia = false;
        return PM;
        }
        else{
            PM =(float) (this.PM * 1.5);
        PM = InimigoArma.Magia(PM);
        this.PularTurno = false;
        this.SemMagia = false;
        return PM / 2;
        }
       }
        else{
            this.SemMagia = true;
            this.PularTurno = true;
            return 0;
        }
    }

    public void ação(int atacar, int Defender, int porçãoV, int porçãoM, int Magia, Jogador jogador) {
        int ação;
        float aux;
        if ((this.VidaAtual + InimigoArmadura.getConstante()) > jogador.getForca()
                && (this.VidaAtual + InimigoArmadura.getConstante()) > jogador.getDestreza()) {
            if (atacar == 0) {
                atacar = -1;
                porçãoV += Defender;
                porçãoM += porçãoV;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);
                this.Açao = ação;
                if (ação <= Defender) {
                    Defesa = true;
                } else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                } else if (ação <= porçãoM && ação > porçãoV) {
                    UsarPoção(2);
                } else {
                    aux = Magia();
                    if(aux != -1){

                    }
                }
            } else if (Defender == 0) {
                Defender = -1;
                porçãoV += atacar;
                porçãoM += porçãoV;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= porçãoV && ação > atacar) {
                    UsarPoção(1);
                } else if (ação <= porçãoM && ação <= porçãoV) {
                    UsarPoção(2);
                } else {
                    jogador.TomarDano(Magia());
                }
            } else if (porçãoV == 0) {
                porçãoV = -1;
                Defender += atacar;
                porçãoM += Defender;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                }

                else if (ação <= porçãoM && ação > Defender) {
                    UsarPoção(2);
                }

                else {
                    jogador.TomarDano(Magia());
                }
            }

            else if (porçãoM == 0) {
                porçãoM = -1;
                Defender += atacar;
                porçãoV += Defender;
                Magia += porçãoV;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                }

                else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                }

                else {
                    
                }
            }

            else if (Magia == 0 && porçãoM == 0) {
                Magia = -1;
                porçãoM = -1;
                Defender += atacar;
                porçãoV += Defender;
                ação = Ação.nextInt(porçãoV);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                }

                else {
                    UsarPoção(1);
                }
            }

            else {
                Defender += atacar;
                porçãoV += Defender;
                porçãoM += porçãoV;
                Magia += porçãoM;

                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                }

                else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                }

                else if (ação <= porçãoM && ação > porçãoV) {
                    UsarPoção(2);
                }

                else {
                    jogador.TomarDano(Magia());
                }
            }
        } else if ((aux = porções.getQPorçõesVida()) > 0
                && (this.VidaAtual <= jogador.getForca() || this.VidaAtual <= jogador.getDestreza())) {
            UsarPoção(1);
        } else {
            if (atacar == 0) {
                atacar = -1;
                porçãoV += Defender;
                porçãoM += porçãoV;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);
                if (ação <= Defender) {
                    Defesa = true;
                    this.PularTurno = false;
                } else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                } else if (ação <= porçãoM && ação > porçãoV) {
                    UsarPoção(2);
                } else {
                    jogador.TomarDano(Magia());
                }
            } else if (Defender == 0) {
                Defender = -1;
                porçãoV += atacar;
                porçãoM += porçãoV;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= porçãoV && ação > atacar) {
                    UsarPoção(1);
                } else if (ação <= porçãoM && ação <= porçãoV) {
                    UsarPoção(2);
                } else {
                    jogador.TomarDano(Magia());
                }
            } else if (porçãoV == 0) {
                porçãoV = -1;
                Defender += atacar;
                porçãoM += Defender;
                Magia += porçãoM;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                    this.PularTurno = false;
                }

                else if (ação <= porçãoM && ação > Defender) {
                    UsarPoção(2);
                }

                else {
                    jogador.TomarDano(Magia());
                }
            }

            else if (porçãoM == 0) {
                porçãoM = -1;
                Defender += atacar;
                porçãoV += Defender;
                Magia += porçãoV;
                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                    this.PularTurno = false;
                }

                else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                }

                else {
                    jogador.TomarDano(Magia());
                }
            }

            else if (Magia == 0) {
                Magia = -1;
                Defender += atacar;
                porçãoV += Defender;
                porçãoM += porçãoV;
                ação = Ação.nextInt(porçãoM);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                    this.PularTurno = false;
                }

                else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                }

                else {
                    UsarPoção(2);
                }
            }

            else {
                Defender += atacar;
                porçãoV += Defender;
                porçãoM += porçãoV;
                Magia += porçãoM;

                ação = Ação.nextInt(Magia);

                if (ação <= atacar) {
                    jogador.TomarDano(DarDano());
                }

                else if (ação <= Defender && ação > atacar) {
                    Defesa = true;
                    this.PularTurno = false;
                }

                else if (ação <= porçãoV && ação > Defender) {
                    UsarPoção(1);
                }

                else if (ação <= porçãoM && ação > porçãoV) {
                    UsarPoção(2);
                }

                else {
                    jogador.TomarDano(Magia());
                }
            }
        }
    }

    public int Drop(int combate) {
        int item = drop.nextInt(3);
        if(item == 1 && combate == 1){
            item++;
        }
        else if(item == 0 && combate == 2){
            item++;
        }// no documento está obrigando a ter que escolher uma nova arma na primeira premiação e uma nova armadura na segunda 
        return item;
    }

}
