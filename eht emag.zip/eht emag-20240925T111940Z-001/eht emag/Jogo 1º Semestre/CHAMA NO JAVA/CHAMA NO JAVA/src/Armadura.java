public class Armadura {
private float Resistencia;
private String Nome;
private int constante;

Armadura(String Nome, float Resistencia, int constate){
this.Nome = Nome;
this.Resistencia = Resistencia;
this.constante = constate;
}


public float Defender(){
float Defesa;
Defesa = (float) (constante + (1.5 * Resistencia));
return Defesa;
}

public int getConstante() {
    return constante;
}

public void setResistencia(float resistencia) {
    this.Resistencia = resistencia;
}

public String getNome() {
    return Nome;
}


public void DropaArmadura(){
    System.out.println("Nome: " + this.Nome);
    System.out.println("Defesa da Armadura: " + this.constante);
}
public void trocarArmadura(String nome,int constante){
    this.Nome = nome;
    this.constante = constante;
}
}
