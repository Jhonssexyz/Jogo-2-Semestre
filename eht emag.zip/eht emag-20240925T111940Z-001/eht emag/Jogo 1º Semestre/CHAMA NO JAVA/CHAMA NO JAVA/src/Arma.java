public class Arma {
private int T, Constante;
private float Destreza; // tipo 1 é arma leve e tipo 2 arma pesada a constate arma é o ataque base
private String Nome;

Dados DadosDeAtaque = new Dados();

Arma(String Nome, int T,int Constante,float Destreza){
this.T = T;
this.Nome = Nome;
this.Constante = Constante;
this.Destreza = Destreza;
}

public float CalularDano(float Força){
if(T == 1){
Força = (float) (DadosDeAtaque.D12(1) + (Força * 1.5) + this.Constante);
}
else if(T == 2){
Força = (float) (DadosDeAtaque.D6(2) + DadosDeAtaque.D4(1) + (this.Destreza * 1.5) + this.Constante);
}
else if(T == 3){
Força = (float) (DadosDeAtaque.D4(1) + DadosDeAtaque.D12(1) + Força + this.Destreza);
}
return Força;
}

public float Magia(float PM){
PM = (float) (PM + DadosDeAtaque.D6(2));
return PM;
}

public String getNome() {
return Nome;
}

public int getT() {
    return T;
}

public int getConstante() {
    return Constante;
}

public void setDestreza(float Destreza){
this.Destreza = Destreza;
}

public void trocarArma(String Nome, int T, int Constante){
    this.Nome = Nome;
    this.T = T;
    this.Constante = Constante;
}

public void CombinarArmas(String Nome, int T, int Constante){
    this.Nome = Nome;
    this.Constante = Constante;
    
    if(T != this.T){
        this.T += T;
    }
}

public void DropaArma(){
    System.out.println("Nome: " + this.Nome);
        if(T == 1){
            System.out.println("Tipo: Arma Pesada");
        }
        
        else if(T == 2){
            System.out.println("Tipo: Arma Leve");
        }
        else if(T == 3){
            System.out.println("Tipo: Arma Híbrida");
        }
    System.out.println("Dano da Arma: " + this.Constante);
}
}

