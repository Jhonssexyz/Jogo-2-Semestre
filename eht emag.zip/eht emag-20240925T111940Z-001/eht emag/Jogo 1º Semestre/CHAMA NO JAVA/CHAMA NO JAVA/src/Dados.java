import java.util.Random;
public class Dados {
Random Dado = new Random();
private float Resultado;
private int  aux = 0;
public float D4(int Roladas){
    while (aux <= Roladas){
    Resultado += Dado.nextInt(1, 5);   
    aux++;
}
return Resultado;
}
public float D6(int Roladas){
    while (aux <= Roladas){
    Resultado += Dado.nextInt(1, 7);   
    aux++;
}
return Resultado;
}
public float D8(int Roladas){
    while (aux <= Roladas){
    Resultado += Dado.nextInt(1, 9);   
    aux++;
}
return Resultado;
}
public float D12(int Roladas){
    while (aux <= Roladas){
    Resultado += Dado.nextInt(1, 13); 
    aux++;  
}
return Resultado;
}
}