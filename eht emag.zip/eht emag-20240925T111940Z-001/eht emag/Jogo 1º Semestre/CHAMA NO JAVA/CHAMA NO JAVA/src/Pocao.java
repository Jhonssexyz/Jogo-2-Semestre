public class Pocao {
    private int QPorçõesVida;
    private int QPorçõesMana;
    private float Poder;

    Pocao(int porçãoV, int porçãoM) {
        this.QPorçõesVida = porçãoV;
        this.QPorçõesMana = porçãoM;
    }

    public void poder(float poder) {
        this.Poder = poder;
    }

    public float RecuperarVida(float Vida, float VidaAtual){
        float C = 0;
        if (this.QPorçõesVida > 0 && (this.Poder + VidaAtual) <= Vida && VidaAtual != Vida) {
            this.QPorçõesVida--;
            return this.Poder;
        } else if(this.QPorçõesVida > 0 && (this.Poder + VidaAtual) > Vida && VidaAtual != Vida){
            while (VidaAtual <= Vida) {
                VidaAtual++;
                C++;
            }
            this.QPorçõesVida--;
            return C;
        }
        else if(this.QPorçõesVida > 0 && VidaAtual == Vida){
            return -1;
        }
        else{
            return 0;
        }
    }

    public int getQPorçõesMana() {
        return QPorçõesMana;
    }

    public void setQPorçõesMana(int qPorçõesMana) {
        QPorçõesMana = qPorçõesMana;
    }

    public float RecuperarMana(float Mana, float ManaAtual) {
        float C = 0;
        if (this.QPorçõesMana > 0 && (this.Poder + ManaAtual) <= Mana && ManaAtual != Mana) {
            this.QPorçõesMana--;
            return this.Poder;
        } else if(this.QPorçõesMana > 0 && (this.Poder + ManaAtual) > Mana && ManaAtual != Mana){
            while (ManaAtual <= Mana) {
                ManaAtual++;
                C++;
            }
            this.QPorçõesMana--;
            return C;
        }
        else if(this.QPorçõesMana > 0 && ManaAtual == Mana){
            return -1;
        }
        else{
            return 0;
        }
        }

    

    public int getQPorçõesVida() {
        return QPorçõesVida;
    }

    public void setQPorçõesVida(int qPorçõesVida) {
        QPorçõesVida = qPorçõesVida;
    }
    
}
