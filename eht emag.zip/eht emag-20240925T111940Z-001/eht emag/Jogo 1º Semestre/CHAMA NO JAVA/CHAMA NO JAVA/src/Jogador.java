import java.util.Scanner;

public class Jogador {
    // Tipos de Dados e Atributos da Classe
    Scanner input = new Scanner(System.in);

    Dados TemDado = new Dados();
    private float forca;

    private float vida;

    private int agilidade;

    private float destreza;

    private float Resistência;

    private float PM;

    private float Mana;

    private float ManaAtual;

    private int Personagem;

    private float vidaAtual;

    private int Exp = 0;

    private int exp_necessario = 100;// serve para sabe quanto precisa para upar de nivel

    private int Nivel = 1;

    private int Pontos; // esses pontos são o que o jogador usar para aumentar suas estatisticas

    private String Nome; /* as variaveis foram privadas para melhor controle */

    private boolean Defesa = false;

    private boolean PularTurno = false;

    private boolean CombinarArmas = false;

    private boolean InicouJogo = true;

    private boolean SemMagia = false;

    private boolean SemPorçãoM = false;

    private boolean SemPorçãoV = false;

    Arma MinhaArma;

    Armadura MinhaArmadura;

    Pocao porções = new Pocao(3, 3);

    public void setPoderPorções(float Poder) {
        porções.poder(Poder);
        this.SemPorçãoM = false;
        this.SemPorçãoV = false;
    }

    // Construtor

    public Jogador(String nome, int personagem, float forca, int agilidade, float destreza, float resistencia, float pm) {
        this.Nome = nome; 
        this.Personagem = personagem; 
        this.forca = forca;
        this.agilidade = agilidade;
        this.destreza = destreza;
        this.Resistência = resistencia;
        this.PM = pm;
    }
    

    /*
     * vida MÁX 80
     * Força MÁX 80
     * Agilidade MÁX 80
     * RSISTÊNCIA MÁX 80
     * Poder Magico/PM MÁX 80
     */
    public void criarArma(String nome, int tipo, int constante) {
        MinhaArma = new Arma(nome, tipo, constante, this.destreza);
    }

    public void criarArmadura(String nome, int constante) {
        MinhaArmadura = new Armadura(nome, this.Resistência, constante);
    }

    public float getVida() {
        return vida;
    }

    public int getPersonagem() {
        return Personagem;
    }

    public boolean getisPularTurno() {
        return PularTurno;
    }
    
    public void setPularTurno(boolean pularTurno) {
        PularTurno = pularTurno;
    }

    public float getMana() {
        return Mana;
    }

    public float getManaAtual() {
        return ManaAtual;
    }

    public float getVidaAtual() {
        return vidaAtual;
    }

    public int getExp() {
        return Exp;
    }

    public int getExp_necessario() {
        return exp_necessario;
    }

    public int getNivel() {
        return Nivel;
    }

    public String getNome() {
        return Nome;
    }

    public float getForca() {
        return forca;
    }

    public float getDestreza() {
        return destreza;
    }

    public int getAgilidade() {
        return agilidade;
    }
    

    public boolean isCombinarArmas() {
        return CombinarArmas;
    }
    
    public void setCombinarArmas(boolean combinarArmas) {
        CombinarArmas = combinarArmas;
    }

    public boolean isSemMagia() {
        return SemMagia;
    }

    public boolean isSemPorçãoM() {
        return SemPorçãoM;
    }

    public boolean isSemPorçãoV() {
        return SemPorçãoV;
    }

    public void Status() {
        System.out.println("Vida: " + this.vida);
        System.out.println("Poder Magico: " + this.PM);
        System.out.println("Força: " + this.forca);
        System.out.println("Agilidade: " + this.agilidade);
        System.out.println("Destreza: " + this.destreza);
        System.out.println("Resistencia: " + this.Resistência);
        System.out.println("Mana: " + this.Mana);
    }
    public void Vida_Mana(){
        this.vida =(float) (TemDado.D6(3) + this.Resistência);
        this.vidaAtual = this.vida;
        this.Mana = (float) (TemDado.D8(3) + this.PM);
        this.ManaAtual = this.Mana;
    }


    // Atribuir 15 pontos nas características


    public void upar(int exp) { // esse exp serve para sabe se ele upou mesmo de level ou não e se sim quantos
                                // leveis
        if (exp >= this.exp_necessario || Pontos > 0) {
            while (exp >= this.exp_necessario) {
                exp -= this.exp_necessario;
                this.exp_necessario += 100;
                this.Nivel++;
                this.Pontos += 5;
                this.vida += 50;
                this.Mana += 50;
                this.vidaAtual = this.vida;
                this.vidaAtual = this.vida;
                this.ManaAtual = this.Mana;
            }
            this.Exp = exp;
          
            while (this.Pontos > 0) {

                for(int i = 0; i < 50; i++){
                    System.out.println(" ");
                }
               
                System.out.println("Agora você têm " + this.Pontos + " pontos para distibuir");
                //System.out.println( "Escolha o número de pontos que você quer distibuir e a inicial do Status que você quer botar esses pontos\n");
                System.out.println("(F) Força: " + this.forca);
                System.out.println("(D) Destreza: " + this.destreza);
                System.out.println("(R) Resistência: " + this.Resistência);
                System.out.println("(a) Agilidade: " + this.agilidade);
                System.out.println("(PM) Poder Mágico: " + this.PM);
                System.out.println("Agora escolha o atributo que você quer botar pontos");

                
                String Escolha = input.nextLine();
                int E;
               
                if (Escolha == "F" || Escolha == "f") {
                   
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.forca += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                }
                
                
                else if (Escolha.equals("D") || Escolha == "d") {
                    
                  

                    System.out.println("Quantos pontos você quer adicionar?");
        
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.destreza += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        
                        System.out.println("Insira um número maior que zero.");
               
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                } 
                
                
                else if (Escolha.equals("R") || Escolha == "r") {
                
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.Resistência += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }

                } 
                
                
                else if (Escolha.equals("A") || Escolha == "a") {
                  
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.agilidade += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }

                } 
                
                
                else if (Escolha.equals("PM") || Escolha == "pm" || Escolha == "Pm" || Escolha == "Pm") {
                  
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.PM += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                } 
                
                
                else{
                     System.out.println("sigla ivalida!");
                }
            }
        } 
        
        
        
        /*
         * 
         * 
         *      Já foi mexido!!!!!!!!!!!!!!!!
         * 
         */
        else if (InicouJogo == true) {
            this.Pontos = 15;
            while (this.Pontos > 0) {
                for(int j = 0; j < 50; j++){
                    System.out.println(" ");
                }
                System.out.println("você tem Pontos " + this.Pontos + " para distribuir");
                System.out.println("(F) Força: " + this.forca);
                System.out.println("(D) Destreza: " + this.destreza);
                System.out.println("(R) Resistência: " + this.Resistência);
                System.out.println("(A) Agilidade: " + this.agilidade);
                System.out.println("(PM) Poder Mágico: " + this.PM);
                System.out.println("agora escolha o atributo que você quer botar pontos");
                String Escolha = input.nextLine();
                int E;
                if (Escolha.equals("F") || Escolha.equals("f")) {
                    System.out.println("Quantos pontos você quer adicionar?");
        
                E = input.nextInt();
                    
                    if (E > 0 && E <= this.Pontos) {
                        this.forca += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                

                } else if (Escolha.equals("D") || Escolha.equals("d")) {
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.destreza += E;
                        MinhaArma.setDestreza(this.getDestreza());
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                } else if (Escolha.equals("R") || Escolha.equals("r")) {
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.Resistência += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }

                } else if (Escolha.equals("A") || Escolha.equals("a")) {
                    System.out.println("Quantos pontos você quer adiconar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.agilidade += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero.");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }

                } else if (Escolha.equals("PM") ||Escolha.equals("pm") || Escolha.equals("Pm") || Escolha.equals("pM")) {
                    System.out.println("Quantos pontos você quer adicionar?");
                    E = input.nextInt();
                    if (E > 0 && E <= this.Pontos) {
                        this.PM += E;
                        this.Pontos -= E;
                    } else if(E <= 0 && E <= this.Pontos){
                        System.out.println("Insira um número maior que zero");
                        continue;
                    }
                    else{
                        System.out.println("valor maior que a quantia de pontos disponível");
                        continue;
                    }
                } else {
                    System.out.println("sigla invalida!");
                    continue;
                }

            }
            InicouJogo = false;
        } else {
            this.Exp += exp;
        }
    }

    public void TomarDano(float Dano) {
        if (Defesa == true) {
            float aux = Dano - MinhaArmadura.Defender();
            if(aux > 0){
            if(aux <= this.vidaAtual){
            this.vidaAtual -= aux;
            }
            else{
                this.vidaAtual = 0;
            }
            }
        } else {
            if(Dano > 0){
                if(Dano <= this.vidaAtual){
            this.vidaAtual -= Dano - (float) (MinhaArmadura.getConstante());
                }
                else{
                    this.vidaAtual = 0;
                }
            }
        }
    }

    public float DarDano() {
        float Dano = MinhaArma.CalularDano(this.forca);
        return Dano;
    }

    public float Magia() {
        if(this.ManaAtual >= 50){
        this.ManaAtual -= 50;
        PM *= 1.5;
        PM = MinhaArma.Magia(PM);
        this.SemMagia = false;
        this.PularTurno = false;
        return PM;
        }
        else{
            this.SemMagia = true;
            this.PularTurno = true;
            System.out.println("Sua Mana acabou, usei uma porção de Mana ou tentei atacar com sua arma");
            return 0;
        }
    }

    public void UsarPoção(int T) {
        float aux;

        if (T == 1) {
            aux = porções.RecuperarVida(this.vida, this.vidaAtual);

            if (aux > 0) {
                this.vidaAtual = aux;
                this.PularTurno = false;
            }

            else if(aux == 0){
                System.out.println("Acabou suas porções de vida");
                this.SemPorçãoV = true;
                this.PularTurno = true;
            }
            else if(aux < 0){
                System.out.println("Você não precisa recuperar vida");
                this.PularTurno = true;
            }
        }

        else if (T == 2) {
            aux = porções.RecuperarMana(this.Mana, this.ManaAtual);

            if (aux > 0) {
                this.ManaAtual = aux;
                this.PularTurno = false;
            }

            else if(aux == 0){
                System.out.println("Não tem mais poções de Mana");
                PularTurno = true;
            }
            else if(aux > 0){
                System.out.println("Você não precisa de Mana");
                PularTurno = true;
            }
        }
    }
}