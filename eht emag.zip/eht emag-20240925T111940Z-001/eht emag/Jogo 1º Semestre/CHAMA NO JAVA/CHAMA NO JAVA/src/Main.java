import java.util.Scanner;


public class Main {
  Scanner input = new Scanner(System.in);
  int Escolha, Personagem = 0, agilidade;
  float forca, destreza, Resistencia, PM;
  String Nome, E;
  int escolher;
  int i = 0;
  Jogador jogador;
  Dados DadosIniciais = new Dados();

  String NomeArmaInimigo, NomeArmaduraInimmigo;
  int TipoDeArmaInimigo, constanteArmaInimigo, constanteArmaduraInimigo;
  Adversario adversario1 = new Adversario("Neila", 1, 10, 15, 7, 0, 0, 0);
  Adversario adversario2 = new Adversario("Ogam ed ogof (Hsalc Elayor)", 35, 12, 5, 20, 0, 60, 300);
  Adversario adversario3 = new Adversario("Ogavac", 50, 0, 50, 15, 60, 60, 300);
  Adversario Boss = new Adversario("Sarig", 80, 80, 80, 40, 80, 80, 800);

  public void criarArmaEArmadura(String NomeArma, int constanteArma, int Tipo, String NomeArmadura,
      int constanteArmadura, Adversario adversario) {
    NomeArmaInimigo = NomeArma;
    NomeArmaduraInimmigo = NomeArmaInimigo;
    TipoDeArmaInimigo = Tipo;
    constanteArmaInimigo = constanteArma;
    constanteArmaduraInimigo = constanteArmadura;
    adversario.criarArma(NomeArma, Tipo, constanteArma);
    adversario.criarArmadura(NomeArmadura, constanteArmadura);
  }


  
  
  // Inicio do jogo
  public void menu() {
    System.out.println("Qual vai ser seu nome?");
    Nome = input.nextLine();
    for(int i = 0; i < 10; i++){
      System.out.println(" ");
    }
    
           // Códigos de escape ANSI para cores
           final String RED = "\u001B[31m";
           final String YELLOW = "\u001B[33m";
           final String RESET = "\u001B[0m";
           final String GREEN = "\u001B[32m";
           final String BLUE = "\u001B[34m";
           final String CYAN = "\u001B[36m";
           final String MAGENTA = "\u001B[35m";
           final String WHITE = "\u001B[37m";


           System.out.println(RED + "       ,--.       ,--.   ");
           System.out.println(" ,---. |  ,---. ,-'  '-.     ,--,--.,--,--,--. ,---.  ,---. ");
           System.out.println(YELLOW + "| .-. :|  .-.  |'-.  .-'    ' ,-.  ||        || .-. :| .-. | ");
           System.out.println("\\   --.|  | |  |  |  |      \\ '-'  ||  |  |  |\\   --.' '-' ' ");
           System.out.println(RED + "  ----'`--' `--'  `--'       `--`--'`--`--`--' `----'.`-  /  ");
           System.out.println("                                                     `---'     \n" + RESET);
       
    System.out.println(YELLOW + "\n\n\t\t(1) Começa jogo");
    System.out.println(YELLOW + "\t\t(2) História e Status");
    System.out.println(YELLOW + "\t\t(3) Sair Do Jogo");

    for(int i = 0; i < 10; i++){
      System.out.println(" ");
    }
   

    Escolha = input.nextInt();

    for (int i = 0; i < 100; i++) {
      System.out.println(" ");
    }


    if (Escolha == 1) {

      MenuPersonagem();
      Jogo();
    }

    else if (Escolha == 2) {
      História();

    }

    if (Escolha == 3) {
      System.out.println("Até a proxima!");
      System.exit(0);
    }
    if (Escolha != 1 && Escolha != 2 && Escolha != 3) {

      // For que verifica se o usuário inseriu 1,2 ou 3
      for (int i = 0; i < 50; i++) {
        System.out.println(" ");
      }
      System.out.println("Insira uma opção válida!");
      //Thread.sleep(5000);
      menu();
      for (int i = 0; i < 50; i++) {
        System.out.println(" ");
      }
      menu();

    }
  }

  // História dos personagens
  public void História() {

    // Fazendo para que as informações anteriores não apareçam com as novas
    for (int i = 0; i < 50; i++) {
      System.out.println(" ");
    }

    // If para indentificar se o usuário já viu a história dos 3 personagens
    if (i != 3) {
      System.out.println("-- (1) Bombeiro  |||   (2) Ti  |||   (3) Agricultor --");
      Escolha = input.nextInt();

      // Bombeiro
      if (Escolha == 1) {

        // Fazendo para que as informações anteriores não apareçam com as novas
        for (int i = 0; i < 50; i++) {
          System.out.println(" ");
        }

        System.out.format("Ao sair da sua casa, o bombeiro %s ia em direção ao trabalho. Ás 8 horas, quando se aproximava do trabalho, uma caminhão\nlhe tirou da pista. %s perde o controle do carro e colide com o poste. Horas depois, ele acorda e percebe que tudo está diferente\nnão há sol, ele enxerga apenas números binários. %s percebe que está em um jogo! Agora ele terá que achar o caminho de volta pra casa. Passando pelos \ndesafios que encotrará e com medo de não voltar\n\n",Nome,Nome,Nome);
          System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n###########################################\n\n");
        System.out.println("Aperte 0 para o próximo");
        System.out.println("Se não quiser jogar, aperte outra tecla\n\n");

        Escolha = input.nextInt();

        // Lógica para observar a história do outro personagem
        if (Escolha == 0) {
          i = i + 1;
          for (int j = 0; j < 50; j++) {
            System.out.println(" ");
          }
          História();

        } else {
          System.exit(0);
        }
      }

      // Ti
      else if (Escolha == 2) {

        // Fazendo para que as informações anteriores não apareçam com as novas
        for (int j = 0; j < 50; j++) {
          System.out.println(" ");
        }

        System.out.println("");

        System.out.format("Apaixonado por computadores e química. %s estudava o decaimento de elementos que estavam em fusão. Em certa parte do experimento,\nos reatores começaram a aquecer descontroladamente. %s tentou diminuir a temperatura, mas a água contida nos reservarórios sumiu.\nSem ter o que fazer, %s apenas observou o cénario... Horas depois ele acorda e percebe que tudo está diferente!\nHá escuridão! %s percebe que está em outro lugar! Agora ele terá que achar o caminho de volta pra casa. Passando pelos desafios que encotrará e com medo de não voltar",Nome,Nome,Nome,Nome);
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n###########################################\n\n");
        System.out.println("Aperte 0 para o próximo");
        System.out.println("Se não quiser jogar, aperte outra tecla\n\n");

        Escolha = input.nextInt();

        // Lógica para observar a história do outro personagem
        if (Escolha == 0) {
          i = i + 1;
          História();
        } else {
          System.exit(0);
        }
      }

      // Agricultor
      if (Escolha == 3) {

        // Fazendo para que as informações anteriores não apareçam com as novas
        for (int j = 0; j < 50; j++) {
          System.out.println(" ");
        }

        System.out.println("");

        System.out.format("Cansando da sua rotina monónotona, certo dia o %s decide torma atidude. Há tempos ele sabia da existência de um portal.\nEra azul igual a água. Grande que nem uma casa. Porém, ele nunca havia entrado para explorar. Tendo isso e mente, ele arruma sua bagagem\ndeterminado a entrar no portal. Ao aproximar-se, ele sente um grande medo e percebe que é loucura fazer isso. Mas, ao tentar ir embora\nele é sugado para dentro onde bate a cabeça e fica desacordado. Ao acordar, seus braços e pernas estão diferentes, ele se arrepende de ter entrado no portal.\nDesesperado, ele tenta voltar para sua realidade. Agora ele terá que enfrentar vilões para voltar para casa.",Nome);
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n###########################################\n\n");
        System.out.println("Aperte 0 para o próximo: ");
        System.out.println("Se não quiser jogar, aperte outra tecla\n\n");
        Escolha = input.nextInt();

        //// Lógica para observar a história do outro personagem
        if (Escolha == 0) {
          i = i + 1;
          História();
        } else {
          System.exit(0);
        }

      }

    }

    else if (i == 3) {
      MenuPersonagem();
      Jogo();
    }
  }

  // Completo !!!!!!!!!
  public Jogador MenuPersonagem() {

    System.out.println("Escolha entre os 3 tipos de personagem:\n");
    System.out.println("(1) Bombeiro"); // depois botar uma art ASCII com o nome ou um simbolo da profissão
    System.out.println("-----------------------------------------------");
    System.out.println("Status"); // depois essa parte tem que ser subistituida por uma art ASCII
    System.out.println("Força: 20 ");
    System.out.println("Agilidade: 10 ");
    System.out.println("Resistencia: 25");
    System.out.println("PM: 15");
    System.out.println("Destreza: ");
    System.out.println("Habilidade Special: Resistência ao fogo\n");

    System.out.println("(2) Ti"); // depois botar uma art ASCII com o nome ou um simbolo da profissão
    System.out.println("-----------------------------------------------");
    System.out.println("Status"); // depois essa parte tem que ser subistituida por uma art ASCII
    System.out.println("Força: 15");
    System.out.println("Agilidade: 15");
    System.out.println("Resistencia: 15");
    System.out.println("PM: 25");
    System.out.println("Destreza: ");
    System.out.println("Habilidade Special: Combinar Armas\n");

    System.out.println("(3) agricutor"); // depois botar uma art ASCII com o nome ou um simbolo da profiss22ão
    System.out.println("-----------------------------------------------");
    System.out.println("Status"); // depois essa parte tem que ser subistituida por uma art ASCII
    System.out.println("Força:  25");
    System.out.println("Agilidade: 10");
    System.out.println("Resistencia:  25");
    System.out.println("PM: 10");
    System.out.println("Destreza:  ");
    System.out.println("habilidade special: Seu ataque é dobrado, pois é bom com armas\n\n");
    System.out.println("Qual você escolherá ?");

    String[] personagens = {
        "1. Bombeiro\n" +
            "   O\n" +
            "  /|\\\n" +
            "  / \\\n",
        "2. TI\n" +
            "   O\n" +
            "  /|\\\n" +
            "  / \\\n",
        "3. Agricultor\n" +
            "   O\n" +
            "  /|\\\n" +
            "  / \\\n"
    };

    for (String personagem : personagens) {
      System.out.println(personagem);
      System.out.println("=".repeat(20)); // Separador entre os personagens
    }

    Escolha = input.nextInt();
    

    if (Escolha == 1) {
      Personagem = 1;
      forca = 20;
      agilidade = 10;
      destreza = 15;
      Resistencia = 25;
      PM = 25;

    } else if (Escolha == 2) {
      Personagem = 2;
      forca = 5;
      agilidade = 15;
      destreza = 25;
      Resistencia = 15;
      PM = 25;
    } else if (Escolha == 3) {
      Personagem = 3;
      forca = 35;
      agilidade = 10;
      destreza = 5;
      Resistencia = 25;
      PM = 10;
    }
    jogador = new Jogador(Nome, Personagem, forca, agilidade, destreza, Resistencia, PM);
    return jogador;
  }

  public void pré_jogo() {

    jogador.upar(0);

    for (int i = 0; i < 50; i++) {
      System.out.println(" ");
    }

    Arma PistolaLaser = new Arma("Pistola de Laser", 1, 5, 0);
    Arma Machado = new Arma("Machado de mecúrio", 2, 10, 0);
    Arma KatarsdeLuz = new Arma("Katars de luz", 1, 5, 0);
    System.out.println("Escolha uma das 3 armas a seguir");
    System.out.println("(1)");
    PistolaLaser.DropaArma();
    System.out.println("########################");
    System.out.println("(2)");
    Machado.DropaArma();
    System.out.println("########################");
    System.out.println("(3)");
    KatarsdeLuz.DropaArma();
    System.out.println("########################");
    System.out.println("qual delas você quer?");
    escolher = input.nextInt();

    if (escolher == 1) {
      jogador.criarArma("Pistola de Laser", 2, 20);
    }

    else if (escolher == 2) {
      jogador.criarArma("Machado de mecúrio", 1, 20);
    }

    else if (escolher == 3) {
      jogador.criarArma("Katars de luz", 2, 20);
    }

    for (int i = 0; i < 50; i++) {
      System.out.println(" ");
    }

    System.out.println("Agora é hora de escolher sua armadura\n\n");

    Armadura ArmaduraDeDragão = new Armadura("Armadura de Dragão Negro de Olhos Vermelhos", 0, 50);
    Armadura Armaduratecnologica = new Armadura("Armadura Nevorsa", 0, 50);// Nervosa de sistema nervoso
    Armadura PijamadoSaitama = new Armadura("Pijama (usado pelo Saitama)", 0, 50);
    System.out.println("(1)");
    ArmaduraDeDragão.DropaArmadura();
    System.out.println("##########################");
    System.out.println("(2)");
    Armaduratecnologica.DropaArmadura();
    System.out.println("##########################");
    System.out.println("(3)");
    PijamadoSaitama.DropaArmadura();
    System.out.println("##########################");
    System.out.println("\nqual sua escolha?");
    int E = input.nextInt();
    if (E == 1) {
      jogador.criarArmadura("Armadura de Dragão Negro de Olhos Vermelhos", 200);
    }

    else if (E == 2) {
      jogador.criarArmadura("Armadura Nevorsa", 200);
    }

    else if (E == 3) {
      jogador.criarArmadura("Pijama (usado pelo Saitama)", 200);
    }
    jogador.Vida_Mana();
  }

  public void Jogo() {
    pré_jogo();
    int combate = 1;
   
    while (true) {
      
      if (combate == 1) {
        criarArmaEArmadura("Bazuka de Ions", 10, 1, "Armadura de Diamante Refoçado", 20, adversario1);
       
        jogador.porções.poder(50);
        adversario1.porções.poder(20);
        
        
        while (jogador.getVidaAtual() > 0 && adversario1.getVidaAtual() > 0) {
          if (jogador.getAgilidade() >= adversario1.getAgilidade()) {
            MenuCombate(combate);
            escolher = input.nextInt();
           
            if (escolher == 1) {
              adversario1.TomarDano(jogador.DarDano());
            } 
            
            else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } 
            
            else if (escolher == 3) {
              adversario1.TomarDano(jogador.Magia());
            } 
            
            else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } 
            
            else {
              System.out.println("Valor invalido");
              continue;
            }


            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continua sem Mana");
                continue;
              }

              if (escolher == 1) {
                adversario1.TomarDano(jogador.DarDano());
                if(adversario1.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario1.TomarDano(jogador.Magia());
                if(adversario1.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
            adversario1.ação(7, 7, 6, 0, 0, jogador);
            if (adversario1.getisPularTurno() == true) {
              adversario1.ação(7, 7, 6, 0, 0, jogador);
            }
          } else {
            adversario1.ação(8, 1, 1, 2, 8, jogador);
            if (Boss.getisPularTurno() == true) {
              adversario1.ação(8, 1, 1, 1, 8, jogador);
            }
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              adversario1.TomarDano(jogador.DarDano());
              if(adversario1.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              adversario1.TomarDano(jogador.Magia());
              if(adversario1.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                adversario1.TomarDano(jogador.DarDano());
                if(adversario1.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario1.TomarDano(jogador.Magia());
                if(adversario1.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
          }

        }
        if (jogador.getVidaAtual() <= 0) {
          TelaGameover();
        } else {
          int aux = adversario1.Drop(combate);
          if (aux == 0) {
            System.out.println("O inimigo dropou a arma dele");
            System.out.println("\n\n");
            adversario1.InimigoArma.DropaArma();
            System.out.println("\n quer pegar essa arma?");
            E = input.nextLine();
            if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  if (jogador.getPersonagem() == 3) {
                    constanteArmaInimigo *= 2;
                  }
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
              } else {
                if (jogador.getPersonagem() == 3) {
                  constanteArmaInimigo *= 2;
                }
                jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
              }
            }
          } else if (aux == 2) {
            System.out.println("O inimigo dropou a arma e a armadura dele");
            System.out.println("\n\n");
            adversario1.InimigoArma.DropaArma();
            adversario1.InimigoArmadura.DropaArmadura();
            System.out.println();
            System.out.println("(1) Pegar ambas");
            System.out.println("(2) Pegar a arma");
            System.out.println("(3) Pegar a armadura");
            System.out.println("pressionei qualquer outro número para não pegar nenhum");
            escolher = input.nextInt();
            if (escolher == 1) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              } else {
                if (jogador.getPersonagem() == 3) {
                  constanteArmaInimigo *= 2;
                }
                jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              }
            } else if (escolher == 2) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  if (jogador.getPersonagem() == 3) {
                    constanteArmaduraInimigo *= 2;
                  }
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
              }
            } else if (escolher == 3) {
              jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
            }
          }
        }
        if (jogador.getPersonagem() == 2) {
          jogador.upar(200);
      } else {
          jogador.upar(100);
      }
        combate++;
      }
      
      if (combate == 2) {
        criarArmaEArmadura("Poderoso cajado dos 7 reinos", 10, 1, "Manto do Homem de amarelo", 10, adversario2);
        jogador.porções.poder(75);
        adversario2.porções.poder(75);
        jogador.porções.setQPorçõesVida(3);
        jogador.porções.setQPorçõesMana(3);
        if (jogador.getPersonagem() == 1) {
          adversario2.setMenosDano(true);
        }
        while (jogador.getVidaAtual() > 0 && adversario2.getVidaAtual() > 0) {
          if (jogador.getAgilidade() >= adversario2.getAgilidade()) {
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              adversario2.TomarDano(jogador.DarDano());
              if(adversario2.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              adversario2.TomarDano(jogador.Magia());
              if(adversario2.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                adversario2.TomarDano(jogador.DarDano());
                if(adversario2.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario2.TomarDano(jogador.Magia());
                if(adversario2.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
            adversario2.ação(0, 4, 2, 7, 7, jogador);
            if (adversario2.getisPularTurno() == true) {
              adversario2.ação(0, 4, 2, 7, 7, jogador);
            }
          } else {
            adversario2.ação(8, 1, 1, 2, 8, jogador);
            if (adversario2.getisPularTurno() == true) {
              adversario2.ação(8, 1, 1, 1, 8, jogador);
            }
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              adversario2.TomarDano(jogador.DarDano());
              if(adversario2.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              adversario2.TomarDano(jogador.Magia());
              if(adversario2.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                adversario2.TomarDano(jogador.DarDano());
                if(adversario2.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario2.TomarDano(jogador.Magia());
                if(adversario2.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
          }

        }
        if (jogador.getVidaAtual() <= 0) {
          TelaGameover();
          escolher = input.nextInt();
          if (escolher == 1) {
            continue;

          } else {
            System.exit(1);
          }
        } else {
          int aux = adversario2.Drop(combate);
          if (aux == 1) {
            System.out.println("O inimigo dropou a arma dele");
            System.out.println("\n\n");
            adversario2.InimigoArmadura.DropaArmadura();
            System.out.println("\n quer pegar essa armadura?");
            E = input.nextLine();
            if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
              if (jogador.getPersonagem() == 3) {
                constanteArmaInimigo *= 2;
              }
              jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
            }
          } else if (aux == 2) {
            System.out.println("O inimigo dropou a arma e a armadura dele");
            System.out.println("\n\n");
            adversario2.InimigoArma.DropaArma();
            adversario2.InimigoArmadura.DropaArmadura();
            System.out.println();
            System.out.println("(1) Pegar ambas");
            System.out.println("(2) Pegar a arma");
            System.out.println("(3) Pegar a armadura");
            System.out.println("pressionei qualquer outro número para não pegar nenhum");
            escolher = input.nextInt();
            if (escolher == 1) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              } else {
                if (jogador.getPersonagem() == 3) {
                  constanteArmaInimigo *= 2;
                }
                jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              }
            } else if (escolher == 2) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  if (jogador.getPersonagem() == 3) {
                    constanteArmaduraInimigo *= 2;
                  }
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
              }
            } else if (escolher == 3) {
              jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
            }
          }
        }
        if (jogador.getPersonagem() == 2) {
          jogador.upar(400);
        } else {
          jogador.upar(200);
        }
        combate++;
      }
      
      if (combate == 3) {
        criarArmaEArmadura("Lámina de luz", 20, 2, "Armadura do dicipulo de Sarig", 20, adversario3);
        jogador.porções.poder(100);
        jogador.porções.setQPorçõesVida(3);
        jogador.porções.setQPorçõesMana(3);
        adversario3.porções.poder(100);
        while (jogador.getVidaAtual() > 0 && adversario3.getVidaAtual() > 0) {
          if (jogador.getAgilidade() >= adversario3.getAgilidade()) {
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              adversario3.TomarDano(jogador.DarDano());
              if(adversario3.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              adversario3.TomarDano(jogador.Magia());
              if(adversario3.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                adversario3.TomarDano(jogador.DarDano());
                if(adversario3.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario3.TomarDano(jogador.Magia());
                if(adversario3.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
            adversario3.ação(0, 4, 2, 7, 7, jogador);
            if (adversario3.getisPularTurno() == true) {
              adversario3.ação(0, 4, 2, 7, 7, jogador);
            }
          } else {
            adversario3.ação(8, 1, 1, 2, 8, jogador);
            if (adversario3.getisPularTurno() == true) {
              adversario3.ação(8, 1, 1, 1, 8, jogador);
            }
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              adversario3.TomarDano(jogador.DarDano());
              if(adversario3.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              adversario3.TomarDano(jogador.Magia());
              if(adversario3.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                adversario3.TomarDano(jogador.DarDano());
                if(adversario3.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                adversario3.TomarDano(jogador.Magia());
                if(adversario3.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
          }

        }
        if (jogador.getVidaAtual() <= 0) {
          TelaGameover();
        } else {
          int aux = adversario3.Drop(combate);
          if (aux == 0) {
            System.out.println("O inimigo dropou a arma dele");
            System.out.println("\n\n");
            adversario3.InimigoArma.DropaArma();
            System.out.println("\n quer pegar essa arma?");
            E = input.nextLine();
            if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  if (jogador.getPersonagem() == 3) {
                    constanteArmaInimigo *= 2;
                  }
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
              } else {
                if (jogador.getPersonagem() == 3) {
                  constanteArmaInimigo *= 2;
                }
                jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
              }
            }
          } else if (aux == 1) {
            System.out.println("O inimigo dropou a arma dele");
            System.out.println("\n\n");
            adversario3.InimigoArmadura.DropaArmadura();
            System.out.println("\n quer pegar essa armadura?");
            E = input.nextLine();
            if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
              if (jogador.getPersonagem() == 3) {
                constanteArmaInimigo *= 2;
              }
              jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
            }
          } else if (aux == 2) {
            System.out.println("O inimigo dropou a arma e a armadura dele");
            System.out.println("\n\n");
            adversario3.InimigoArma.DropaArma();
            adversario3.InimigoArmadura.DropaArmadura();
            System.out.println();
            System.out.println("(1) Pegar ambas");
            System.out.println("(2) Pegar a arma");
            System.out.println("(3) Pegar a armadura");
            System.out.println("pressionei qualquer outro número para não pegar nenhum");
            escolher = input.nextInt();
            if (escolher == 1) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              } else {
                if (jogador.getPersonagem() == 3) {
                  constanteArmaInimigo *= 2;
                }
                jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
              }
            } else if (escolher == 2) {
              if (jogador.getPersonagem() == 2 && jogador.isCombinarArmas() == true) {
                System.out.println("Em vez disso que tal combinar com sua arma atual?");
                E = input.nextLine();
                if (E == "S" || E == "s" || E == "SI" || E == "Si" || E == "sI" || E == "si" || E == "SIM" || E == "SIm"
                    || E == "Sim" || E == "sim" || E == "siM" || E == "sIM") {
                  jogador.MinhaArma.CombinarArmas(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                  jogador.setCombinarArmas(false);
                } else {
                  if (jogador.getPersonagem() == 3) {
                    constanteArmaduraInimigo *= 2;
                  }
                  jogador.MinhaArma.trocarArma(NomeArmaInimigo, TipoDeArmaInimigo, constanteArmaInimigo);
                }
              }
            } else if (escolher == 3) {
              jogador.MinhaArmadura.trocarArmadura(NomeArmaduraInimmigo, constanteArmaduraInimigo);
            }
          }
        }
        if(jogador.getVidaAtual() <= 0){
          TelaGameover();
        }
        System.out.println("Você sente uma enegia misteriosa em volta do seu corpo");
        System.out.println("Impedindo que você se mova");
        System.out.println("Você ouve sons de passos se aproximando");
        System.out.println("Uma figura misteriosa passa por você");
        System.out.println("Com a mão envolta de Mágia, a mesma que está te deixando incapacitado de se mover");
        System.out.println("O ser olha para o cádaver do " + adversario3.getNome());
        System.out.println("???: parece que você derrotou meu pupilo");
        System.out.println("Sarig: ohhh, que mal-educação da minha parte, sou o grande Mago Sirag");
        System.out.println("Sarig: solta você");
        System.out.println("Sarig: nesse mundo temos uma tradição chamada Rigat");
        System.out.println("Sarig: quando um mestre tem seu aluno mortou");
        System.out.println("Sarig: ou o mestre treinar aquele que matou seu dicipulo ou o mestre deve matar-lo");
        System.out.println(" o" + adversario3.getNome() + "era meu melhor aprendiz, então farei uma proposta especial para você");
        System.out.println("Sarig: se você virar meu aluno, você será meu sucessor como mago supremo desse planeta");
        System.out.println("Sarig: se não aceitar eu te matarei");
        System.out.println("Sarig: qual sua escolha?");
        System.out.println("Os olhos de Sirag brilham em vermelho e seu corpo é envolto em uma aura da mesma cor");
        System.out.println("Virar aprendiz de Sirag nunca mais voltar ao seu mundo?");
        System.out.println("(1) sim");
        System.out.println("apertei qualquer coisa para negar a proposta");
        escolher = input.nextInt();
        if (escolher == 1) {
          Vitória(true);
          System.exit(0);
        } else {
          System.out.println("Que seja");
          System.out.println("Ele levanta a mão em sua direção");
          System.out.println("Por algum motivo você se sente mais forte");
          if (jogador.getPersonagem() == 2) {
            jogador.upar(400);
          } else {
            jogador.upar(300);
          }
          System.out.println("Agora que eu nivelei o combate");
          System.out.println("Pode vim");
          combate++;
        }
      }
      
      if (combate == 4) {
        criarArmaEArmadura("Poderoso cajado dos 7 reinos", 25, 1, "Manto do Homem de amarelo", 25, Boss);
        jogador.porções.setQPorçõesVida(0);
        jogador.porções.setQPorçõesMana(0);
        jogador.porções.poder(0);
        Boss.porções.poder(175);
        if (jogador.getPersonagem() == 1) {
          Boss.setMenosDano(true);
        }
        while (jogador.getVidaAtual() > 0 && Boss.getVidaAtual() > 0) {
          if (jogador.getAgilidade() >= Boss.getAgilidade()) {
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              Boss.TomarDano(jogador.DarDano());
              if(Boss.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              Boss.TomarDano(jogador.Magia());
              if(Boss.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                Boss.TomarDano(jogador.DarDano());
                if(Boss.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                Boss.TomarDano(jogador.Magia());
                if(Boss.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
            Boss.ação(0, 4, 2, 7, 7, jogador);
            if (Boss.getisPularTurno() == true) {
              Boss.ação(0, 4, 2, 7, 7, jogador);
            }
          } else {
            Boss.ação(8, 1, 1, 2, 8, jogador);
            if (Boss.getisPularTurno() == true) {
              Boss.ação(8, 1, 1, 1, 8, jogador);
            }
            MenuCombate(combate);
            escolher = input.nextInt();
            if (escolher == 1) {
              Boss.TomarDano(jogador.DarDano());
              if(Boss.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 2) {
              jogador.MinhaArmadura.Defender();
            } else if (escolher == 3) {
              Boss.TomarDano(jogador.Magia());
              if(Boss.getVidaAtual() <= 0){
                break;
              }
            } else if (escolher == 4) {
              System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                  + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                  escolher = input.nextInt();
              if (escolher == 1) {
                jogador.UsarPoção(1);
              } else if (escolher == 2) {
                jogador.UsarPoção(2);
              } else {
                System.out.println("Valor invalido");
                continue;
              }
            } else {
              System.out.println("Valor invalido");
              continue;
            }
            while (jogador.getisPularTurno() == true) {
              MenuCombate(combate);
              escolher = input.nextInt();
              if (jogador.isSemMagia() == true && escolher == 3) {
                System.out.println("Você continuar sem Mana");
                continue;
              }
              if (escolher == 1) {
                Boss.TomarDano(jogador.DarDano());
                if(Boss.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 2) {
                jogador.MinhaArmadura.Defender();
              } else if (escolher == 3) {
                Boss.TomarDano(jogador.Magia());
                if(Boss.getVidaAtual() <= 0){
                  break;
                }
              } else if (escolher == 4) {
                System.out.println("(1) Porções de Vida: " + jogador.porções.getQPorçõesVida()
                    + "\t (2) Porções de Mana: " + jogador.porções.getQPorçõesMana());
                escolher = input.nextInt();
                if (jogador.isSemPorçãoV() == true && escolher == 1) {
                  System.out.println("Você continuar sem porções de vida");
                  continue;
                } else if (jogador.isSemPorçãoM() == true && escolher == 2) {
                  System.out.println("Você continuar sem porções de Mana");
                  continue;
                }
                if (escolher == 1) {
                  jogador.UsarPoção(1);
                } else if (escolher == 2) {
                  jogador.UsarPoção(2);
                } else {
                  System.out.println("Valor invalido");
                }
              } else {
                System.out.println("Valor invalido");
              }
              jogador.setPularTurno(false);
            }
          }
        }
        if (jogador.getVidaAtual() <= 0) {
          TelaGameover();
        } else {
          Vitória(false);
          System.exit(0);
        }

      }
    }
  }

  public void TelaGameover() {
    for(int j = 0; j < 50; j++){
      System.out.println(" ");
  }

System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@#########*#%@@@@@@*######@@@@@@####@@@@@@@####%@################@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@%%=:::::::::-*@@@@@%::::::-%%@@@%::::#%@@@@@::::=@-::::-----------@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@::::-@@@@@@@@@@@@*::::%@+:::-@@@%::::::+@#::::::=@-:::-@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%::::*@@@@@@@@@@@@=::::@@@@@@#::::%%:::::::::::::::=@-:::-@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%::::*@@@%-:::::+@+::::@@@@@@#::::%%:::::::::::::::+@-::::::::::*@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%::::*@@@@#*-:::+@+::::======-::::%%::::*#=:-##-:::+@-:::-######%@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%==-:+*#@@@@-:::+@+::::++++++=:::-%%-:::#@#+*@@-:::+@-:::=@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@----+@@@%----*@+----@@@@@@%----%%----#@@@@@@----+@=---=@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@*----------*@+----@@@@@@%----%%----#@@@@@@=---+@=--------------=@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@===========%@@@*====@@@@@@%====%%===============*@+============*@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%====#@@@@@@+===#@*===+@@@@@@%===+%%+===%@@@@@@@@@@@@+===*@@@@@@*++++@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@%++++#@@@@@@++++#@*++++@@@@@@%++++%@++++%@@@@@@@@@@@@*+++*@@@@@@*++++@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@++++%@@@@@@****#@#*****+%@#******@@***********%@@@@@****#@@@@#******@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@****%@@@@@@#***%@%%############%%@@####%%%%%%%@@@@@@#####%%%###%%%%%@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@####%@@@@@@####%@@@%###########@@@@####@@@@@@@@@@@@@###########%%@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@####%@@@@@@####%@@@@@@#######@@@@@@####@@@@@@@@@@@@@#####@@######%@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@###########%@@@@@@@@@@##%@@@@@@@@###############%@#####@@@@#######@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

System.out.println("\n\n\n(1) Reniciar");
int escolhafinal = input.nextInt();
if (escolhafinal == 1) {
  menu();
}
else{
  System.exit(0);
}
  }
  public void Vitória(boolean aceitar){
    if(aceitar == true){
      System.out.println("Após aceitar a treinar com Sarig para ser seu sucessor");
      System.out.println(jogador.getNome() + " adiquiriu muitos des conhecimentos do Sirag");
      System.out.println("Apredendo magias que " + jogador.getNome() + " nem imaginava que existiam");
      System.out.println("E protegendo os seres daquele mundo, antes desconhecido");
      System.out.println("Fim.");
      System.exit(0);
    }
    else{
      System.out.println("Antes de morrer Sarig Abre um protal para seu planeta natal");
      System.out.println("Você passa por ele");
      System.out.println("Voltando a sua vida normal");
    }
  }

  public void MenuCombate(int combate) {
    for (int i = 0; i < 50; i++) {
      System.out.println(" ");
    }

    if (combate == 1) {
      System.out.println("*************************************");
      System.out.println("*                                   *");
      System.out.println("*        " + adversario1.getNome() + "                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario1.getVidaAtual() + "/" + adversario1.getVida() + "|                 *");
      System.out.println("*        -----                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario1.getManaAtual() + "/" + adversario1.getMana() + "|                   *");
      System.out.println("*        -----                      *");
      System.out.println("*                                   *");
      System.out.println("*************************************");
    }

    else if (combate == 2) {
      System.out.println("*************************************");
      System.out.println("*                                   *");
      System.out.println("*        " + adversario2.getNome() + "                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario2.getVidaAtual() + "/" + adversario2.getVida() + "|                 *");
      System.out.println("*        -----                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario2.getManaAtual() + "/" + adversario2.getMana() + "|                   *");
      System.out.println("*        -----                      *");
      System.out.println("*                                   *");
      System.out.println("*************************************");
    } else if (combate == 3) {
      System.out.println("*************************************");
      System.out.println("*                                   *");
      System.out.println("*        " + adversario3.getNome() + "                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario3.getVidaAtual() + "/" + adversario3.getVida() + "|                 *");
      System.out.println("*        -----                      *");
      System.out.println("*        _____                      *");
      System.out
          .println("*       |" + adversario3.getManaAtual() + "/" + adversario3.getMana() + "|                   *");
      System.out.println("*        -----                      *");
      System.out.println("*                                   *");
      System.out.println("*************************************");
    } else if (combate == 4) {
      System.out.println("*************************************");
      System.out.println("*                                   *");
      System.out.println("*        " + Boss.getNome() + "                      *");
      System.out.println("*        _____                      *");
      System.out.println("*       |" + Boss.getVidaAtual() + "/" + Boss.getVida() + "|                 *");
      System.out.println("*        -----                      *");
      System.out.println("*        _____                      *");
      System.out.println("*       |" + Boss.getManaAtual() + "/" + Boss.getMana() + "|                   *");
      System.out.println("*        -----                      *");
      System.out.println("*                                   *");
      System.out.println("*************************************");
    }

    System.out.format("\n\nNome: %s |  Nível: %d", jogador.getNome(), jogador.getNivel());
    System.out.format("\nVida atual %.1f | Vida %.1f ", jogador.getVidaAtual(), jogador.getVida());
    System.out.format("\nMana atual %.1f | Mana %.1f ", jogador.getManaAtual(), jogador.getMana());
    System.out.format("\nExperiência: %d | Experiência necessária %d ", jogador.getExp(), jogador.getExp_necessario());

    System.out.println("\n\n(1) Ataque");
    System.out.println("(2) Defender");
    System.out.println("(3) usar mágia");
    System.out.println("(4) usar poção");
  }

  public static void main(String[] args) throws Exception {

    // Instanciando o objeto
    Main Principal = new Main();
    Principal.menu();
  }
}
